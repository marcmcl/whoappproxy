#import <Flutter/Flutter.h>

@interface WhoappproxyPlugin : NSObject<FlutterPlugin>
@end
