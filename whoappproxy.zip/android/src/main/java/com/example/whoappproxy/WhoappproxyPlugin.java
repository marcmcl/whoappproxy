package com.example.whoappproxy;

import java.lang.reflect.Method;
import androidx.annotation.NonNull;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.ProxyInfo;

import io.flutter.embedding.engine.plugins.FlutterPlugin;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.common.MethodChannel.MethodCallHandler;
import io.flutter.plugin.common.MethodChannel.Result;
import io.flutter.plugin.common.PluginRegistry.Registrar;

/** WhoappproxyPlugin */
public class WhoappproxyPlugin implements FlutterPlugin, MethodCallHandler {
  /// The MethodChannel that will the communication between Flutter and native Android
  ///
  /// This local reference serves to register the plugin with the Flutter Engine and unregister it
  /// when the Flutter Engine is detached from the Activity
  private final Registrar registrar;
  private final ConnectivityManager manager;
  private MethodChannel channel;

  public WhoappproxyPlugin(Registrar registrar) {
    this.registrar = registrar;
    this.manager = (ConnectivityManager) registrar
    .context()
    .getApplicationContext()
    .getSystemService(Context.CONNECTIVITY_SERVICE);
  }

  @Override
  public void onAttachedToEngine(@NonNull FlutterPluginBinding flutterPluginBinding) {
    channel = new MethodChannel(flutterPluginBinding.getBinaryMessenger(), "whoappproxy");
    channel.setMethodCallHandler(this);
  }

  @Override
  public void onMethodCall(@NonNull MethodCall call, @NonNull Result result) {
    String proxy, proxyHost, proxyPort;

    if (call.method.equals("getProxy")) {
      try 
      {
        ProxyInfo proxyInfo = this.manager.getDefaultProxy();
        proxyHost = proxyInfo.getHost();
        proxyPort = String.valueOf(proxyInfo.getPort());
        if(proxyHost != null && proxyPort != null)
        {
          proxy = proxyHost + ":" + proxyPort;
        } else {
          proxy = "";
        }
        result.success(proxy);
      }
      catch (Exception e)
      {
        result.success("");
      }
    } else {
      result.notImplemented();
    }
  }

  @Override
  public void onDetachedFromEngine(@NonNull FlutterPluginBinding binding) {
    channel.setMethodCallHandler(null);
  }
}
