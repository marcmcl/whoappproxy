//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<whoappproxy/WhoappproxyPlugin.h>)
#import <whoappproxy/WhoappproxyPlugin.h>
#else
@import whoappproxy;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [WhoappproxyPlugin registerWithRegistrar:[registry registrarForPlugin:@"WhoappproxyPlugin"]];
}

@end
